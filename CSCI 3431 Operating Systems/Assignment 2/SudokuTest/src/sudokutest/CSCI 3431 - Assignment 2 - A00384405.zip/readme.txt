The program works up until the multi-threading step. Both test files are
parsed successfully and the workers for checking the column and row validity
work successfully. unfortunately there's no output stream so testing was done
using a debugger.
