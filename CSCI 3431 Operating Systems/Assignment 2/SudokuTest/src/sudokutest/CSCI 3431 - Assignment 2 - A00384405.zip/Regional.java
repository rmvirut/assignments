package sudokutest;

/**
 *
 * @author Kojo
 */
public class Regional implements Runnable {

    private int[][] region;

    public Regional(int[][] region) {
        this.region = region;
    }

    @Override
    public void run() {
        
    }
    
    
}
