/**
 * Bank.java interface
 * <p>
 * Solutions to the Bankers Algorithm must
 * implement this interface.
 *
 * @author Gagne, Galvin, Silberschatz
 * Operating System Concepts with Java - Eighth Edition
 * Copyright John Wiley & Sons - 2010.
 */

public interface Bank {

    int NUMBER_OF_CUSTOMERS = 5;

    /**
     * Add a customer to the bank.
     *
     * @param customerNumber The number of the customer being added.
     * @param maximumDemand      The maximum demand for this customer.
     */
    void addCustomer(int customerNumber, int[] maximumDemand);

    /**
     * Outputs the available, allocation, max, and need matrices.
     */
    void getState();

    /**
     * Make a request for resources.
     *
     * @param customerNumber The number of the customer being added.
     * @param request        The request from this customer.
     * @return false The request is not granted.
     */
    boolean requestResources(int customerNumber, int[] request);

    /**
     * Release resources.
     *
     * @param customerNumber The number of the customer being added.
     * @param release        The resources to be released.
     */
    void releaseResources(int customerNumber, int[] release);
}
