Puzzle class {

    

}