import sys
import re
from socket import *

serverIP = "localhost"
serverPort = int(sys.argv[1])

clientSocket = socket(AF_INET,SOCK_STREAM)
clientSocket.connect((serverIP, serverPort))

sentence = input('Say something to the server')
clientSocket.sendall(sentence.encode('utf-8'))

response = clientSocket.recv(1024)

print('From server:', response.decode('utf-8'))
clientSocket.close()