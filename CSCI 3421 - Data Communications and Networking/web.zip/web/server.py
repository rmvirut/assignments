import sys
import urllib
from socket import *

serverName = 'localhost'
serverPort = int(sys.argv[1])
serverSocket = socket(SOCK_DGRAM)
serverSocket.bind((serverName, serverPort))

serverSocket.listen(1)
print('Server is online and ready')

while 1:
    connectionSocket, addre = serverSocket.accept()

    request = connectionSocket.recv(1024)
    requestParsed = request.decode('utf-8')
    # read first line which is GET request
    get_request = requestParsed.splitlines()[0]
    print(get_request, ' is what the browser wants')
    # get the request file
    # directory = request.

    # if not available send right error


    # else send the file
    connectionSocket.sendall(requestParsed.encode('utf-8'))

    connectionSocket.close()
