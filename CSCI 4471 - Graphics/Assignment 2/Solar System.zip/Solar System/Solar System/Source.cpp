#include <stdlib.h>
#include <GL\freeglut.h>
#include <GL\glut.h>

// cube vertices
GLfloat vertices[][3] = { { -1.0,-1.0,-1.0 },{ 1.0,-1.0,-1.0 },{ 1.0,1.0,-1.0 },{ -1.0,1.0,-1.0 },
{ -1.0,-1.0, 1.0 },{ 1.0,-1.0, 1.0 },{ 1.0,1.0, 1.0 },{ -1.0,1.0, 1.0 } };

// colors of the vertices
GLfloat colors[][3] = { { 0.0,0.0,0.0 },{ 1.0,0.0,0.0 },{ 1.0,1.0,0.0 },{ 0.0,1.0,0.0 },
{ 0.0,0.0,1.0 },{ 1.0,0.0,1.0 },{ 1.0,1.0,1.0 },{ 0.0,1.0,1.0 } };

void polygon(int a, int b, int c, int d)
{

	glBegin(GL_POLYGON);
	glColor3fv(colors[a]);
	glVertex3fv(vertices[a]);

	glColor3fv(colors[b]);
	glVertex3fv(vertices[b]);

	glColor3fv(colors[c]);
	glVertex3fv(vertices[c]);

	glColor3fv(colors[d]);
	glVertex3fv(vertices[d]);
	glEnd();
}


/************************************************************************

Function:		colorcube

Description:	Map the vertices to cube faces.

*************************************************************************/
void colorcube()
{
	polygon(0, 3, 2, 1);
	polygon(2, 3, 7, 6);
	polygon(0, 4, 7, 3);
	polygon(1, 2, 6, 5);
	polygon(4, 5, 6, 7);
	polygon(0, 1, 5, 4);
}

void planets() {
	/*Draw the sun*/

	glColor3f(0.58, 0.96, 1);
	GLUquadric *quad;
	quad = gluNewQuadric();
	gluSphere(quad, 25, 0, 0);

}

void myIdle() {
	//does nothing now
}

void display() {

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	colorcube();

	glFlush();
}

void initializeGL(void) {
	// enable depth test
	glEnable(GL_DEPTH_TEST);
	// set background color
	glClearColor(0.0, 0.0, 0.0, 1.0);
	// set matrix mode
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// use 3d
	glOrtho(1.0, 1.0, 1.0, 1.0, 0.1, 10.0);
	// now change matrix mode to allow re-positioning
	glMatrixMode(GL_MODELVIEW);
}


void main(int argc, char** argv) {

	//initialize
	glutInit(&argc, argv);
	//display mode
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	//window size
	glutInitWindowSize(1080, 600);
	//window position
	glutInitWindowPosition(100, 100);
	//creat window with title
	glutCreateWindow("Solar System");

	//initialize context
	initializeGL();
	//set display function
	glutDisplayFunc(display);
	//idle function
	glutIdleFunc(myIdle);
	//start even loop
	glutMainLoop();

}

