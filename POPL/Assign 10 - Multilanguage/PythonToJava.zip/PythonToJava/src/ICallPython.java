import java.io.*;
import java.util.*;

/**
 * Welcome to the ICallPython program which calls a python 3.6.1 script known as
 * wait for it.... "iampython.py and then gives it some numbers to do stuff
 * with.
 * 
 * The DCOM, ZMQ and CORBA stuff were really confusing so this is the best
 * cross-language application I could write on such short notice and still make
 * time to prep for exams
 * 
 * @author Kojo Acquah
 */
public class ICallPython {

	public static void main(String a[]) {

		Scanner input = new Scanner(System.in);// keyboard
		int[] args = getInput(input);

		try {
			String pythonScriptPath = "/Users/uduakumoeka/Desktop/Kojo/Repos/PythonToJava/src/iampython.py";
			String[] arguments = new String[5];
			arguments[0] = "python";
			arguments[1] = pythonScriptPath;
			for (int i = 0; i < 3; i++) {
				arguments[i + 2] = String.valueOf(args[i]);
			}

			// run the script with the arguments
			Runtime RT = Runtime.getRuntime();
			Process PR = RT.exec(arguments);

			// get the output
			BufferedReader bfr = new BufferedReader(new InputStreamReader(PR.getInputStream()));
			String line = "";
			while ((line = bfr.readLine()) != null) {
				// display python runtime
				System.out.println(line);
			}

		} catch (Exception e) {
			System.out.print(e.toString());
		}
	}

	/**
	 * Prompts the user for three values to be used in calling the external
	 * program
	 * 
	 * @param k
	 *            main program's scanner input stream
	 * @return an array of 3 integers collected from the user
	 */
	public static int[] getInput(Scanner k) {
		int[] ret = new int[3];
		for (int i = 0; i < 3; i++) {

			if (i != 2) {
				System.out.print("Enter enter number " + (i + 1) + ": ");
				ret[i] = k.nextInt();
			} else {
				boolean badEntry = true;
				do {
					System.out.print("Enter the final number [cannot be 0]: ");
					ret[i] = k.nextInt();
					if (ret[i] != 0) {
						badEntry = false;
					}
				} while (badEntry);
			}

			k.nextLine();
		}

		return ret;

	}
}
