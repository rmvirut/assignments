import sys

# if there are no arguments passed to teh program just close it
if sys.argv.__len__() < 4:
    print("No arguments provided on script call. Exiting now")
    exit(0)

args = []

for i in sys.argv[1:4]:
    args.append(int(i))


def mainJob(A, B, C):
    return int(((A / B) - C))


print(mainJob(args[0], args[1], args[2]))
