package assignment3;

import java.util.*;

/**
 *
 * @author s4979389
 */
public class Assignment3 {

    //holds all EventCalendars creadeted at runtime
    static ArrayList<EventsCalendar> calendars = new ArrayList<>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner kbd = new Scanner(System.in);
        int response;

        do {
            prompt();
            response = kbd.nextInt();
            kbd.nextLine();
            switch (response) {
                case 1:
                    newCalendar();
                    break;
                case 2:
                    createNewEvent();
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
                default:
                    break;
            }

        } while (response != 6);

    }

    public static void newCalendar() {
        Scanner in = new Scanner(System.in);
        String name = "";
        String owner = "";
        //prompt user for calendar info
        System.out.printf("\n%s\n", "Please enter the name of the new Calendar");
        name = in.nextLine();
        System.out.println("Does this calendar have an owner?(yes/no)");
        if (in.nextLine().equalsIgnoreCase("yes")) {
            System.out.print("Enter the owner's name: ");
            owner = in.nextLine();
        }
        //create new calendar
        calendars.add(new EventsCalendar(name, owner));
    }

    public static void createNewEvent() {
        Scanner in = new Scanner(System.in);
        listCalendars();
        int response = in.nextInt();
        Event newEvent = new Event();
        //add to the specified calendar
        calendars.get(response).addEvent(newEvent);
        System.out.printf("Event number %d created with null parameters\n", newEvent.getEventNum());
        //get details for the newly created event
        System.out.println("Please enter the event type");
        newEvent.setType(in.nextLine());
        System.out.println("Please enter the event title");
        newEvent.setTitle(in.nextLine());
        System.out.println("Please enter the event priority");
        newEvent.setPriority(in.nextInt());
        System.out.println("Please enter the event time (0-23");
        newEvent.setTime(in.nextInt());
        System.out.println("Please enter the day of the month");
        newEvent.setDay(in.nextInt());
        System.out.println("Please enter the month");
        newEvent.setMonth(in.nextInt());
        System.out.println("Please enter the year");
        newEvent.setYear(in.nextInt());
        System.out.println("Please enter the list of invitees separated by the comma");
        newEvent.addInvitees(in.nextLine());
        System.out.println(newEvent.toString());
    }

    public static void prompt() {
        System.out.println("Please enter your choice from the available options:");
        String[] prompts = {"add a new calendar", "add an event to an existing calendar",
            "display empty calendar", "display all events in a specific calendar for a specific month/year",
            "display reminders for the closest events within the specified number of days",
            "exit program"};

        for (int i = 0; i < prompts.length; i++) {
            System.out.printf("%d) %s\n", i + 1, prompts[i]);
        }
        System.out.print(": ");
    }

    public static void listCalendars() {
        System.out.println("Please choose from one of the following calendars: ");
        for (int i = 0; i < calendars.size(); i++) {
            System.out.printf("Calendar#%d %s", i, calendars.get(i));
        }
    }
}
